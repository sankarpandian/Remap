<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lms_table extends Model
{
    //
}
