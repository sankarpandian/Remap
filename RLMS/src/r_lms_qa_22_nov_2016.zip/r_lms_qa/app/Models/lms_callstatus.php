<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_callstatus extends Model
{
    //protected $primaryKey = 'lmscs_call_status_id';
	protected $table = 'lms_callstatus';
}
