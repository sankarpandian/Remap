<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_weeks extends Model
{
    protected $primaryKey = 'lw_WeekId';
    protected $table = 'lms_weeks';
}
