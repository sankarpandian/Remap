<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_slots extends Model
{
    protected $primaryKey = 'ls_SlotId';
    protected $table = 'lms_slots';
}
