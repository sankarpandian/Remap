<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_timemasters extends Model
{
    protected $primaryKey = 'ltm_TimeMasterId';
    protected $table = 'lms_timemasters';
}
