<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_callfroms extends Model
{
    //
}
