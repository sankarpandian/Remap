<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_call_details extends Model
{
    //
}
