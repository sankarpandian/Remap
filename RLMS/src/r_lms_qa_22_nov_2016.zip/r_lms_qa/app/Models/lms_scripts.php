<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_scripts extends Model
{
    //
	Protected $primaryKey = 'ls_ScriptId';
}
