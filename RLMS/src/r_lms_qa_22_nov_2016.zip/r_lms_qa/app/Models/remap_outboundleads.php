<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class remap_outboundleads extends Model
{
    protected $primaryKey = 'rol_OutboundLeadId';
    protected $table = 'remap_outboundleads';
}