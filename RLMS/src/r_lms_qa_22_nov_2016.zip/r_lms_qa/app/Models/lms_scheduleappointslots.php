<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_scheduleappointslots extends Model
{
    //
	protected $primaryKey = 'lsa_ScheduleAppointId';
}
