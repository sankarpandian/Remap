<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class remap_dashboardrelations extends Model
{
    //
	protected $table = 'remap_dashboardrelations';
}
