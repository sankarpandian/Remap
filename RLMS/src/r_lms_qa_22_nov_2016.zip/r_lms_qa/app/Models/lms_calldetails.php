<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_calldetails extends Model
{
    protected $primaryKey = 'lld_CallDetailId';
    protected $table = 'lms_calldetails';
}
