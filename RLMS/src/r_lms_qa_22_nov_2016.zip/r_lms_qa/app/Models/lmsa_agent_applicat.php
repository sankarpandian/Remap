<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lmsa_agent_applicat extends Model
{
    //
}
