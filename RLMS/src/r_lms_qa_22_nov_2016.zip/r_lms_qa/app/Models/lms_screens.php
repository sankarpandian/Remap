<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_screens extends Model
{
    //
	protected $primaryKey = 'lsn_ScreentId';
}
