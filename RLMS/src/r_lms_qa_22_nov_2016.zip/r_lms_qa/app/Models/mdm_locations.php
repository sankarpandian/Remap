<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class mdm_locations extends Model
{
    //
}
