<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_slotrelations extends Model
{
    protected $primaryKey = 'lsr_SlotRelationId';
    protected $table = 'lms_slotrelations';
}
