<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class lms_duplicaterecords extends Model
{
    protected $primaryKey = 'ldr_DuplicateRecordId';
    protected $table = 'lms_duplicaterecords';
}