<?php

namespace App\Calendar_Models;

use Illuminate\Database\Eloquent\Model;

class lms_slots extends Model
{
    //
}
