<?php

namespace App\Calendar_Models;

use Illuminate\Database\Eloquent\Model;

class lms_slotrelations extends Model
{
    //
}
