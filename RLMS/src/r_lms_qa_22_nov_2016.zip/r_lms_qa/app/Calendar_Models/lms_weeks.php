<?php

namespace App\Calendar_Models;

use Illuminate\Database\Eloquent\Model;

class lms_weeks extends Model
{
    //
}
