<?php

namespace App\Calendar_Models;

use Illuminate\Database\Eloquent\Model;

class lms_call_status extends Model
{
    //
}
