<?php

namespace App\Calendar_Models;

use Illuminate\Database\Eloquent\Model;

class lms_time_masters extends Model
{
    //
}
